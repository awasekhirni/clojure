(ns ex03appthree.core
  (:gen-class))

(require 'clojure.string)

(defn -main
  "I don't do a whole lot ... yet."
  [& args]
  (println(clojure.string/split "Syed,Awase,Khirni" #",")))



