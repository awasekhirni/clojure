(ns ex04cljprj.core
  (:gen-class))

;importing other modules into your application using require
  (require 'clojure.string)
  (require '[clojure.string :as s])
;to import all the classes in the module 
;(require '[clojure.string :refer :all])
;importing java libraries 
; (import 'java.util.Date)
; (:import [java.util Date Calendar])

(defn -main
  "I don't do a whole lot ... yet."
  [& args]
  (println (clojure.string/split "Syed,Awase,Khirni" #","))
  (println (s/split "hakuna;matata" #";"))
  ; (jEx)
  )

; (defn jEx 
;     (Date. (System/currentTimeMillis))
;     (println (. (Date.) getTime))
;     (println(.getTime (Date.))))
