(ns ex05cljwebprj.core
  (:gen-class :main true)
  (:use compojure.core
        ring.middleware.json
        ring.util.response
        ring.adapter.jetty)
  (:require [compojure.route :as route]
            [ex05cljwebprj.view :as view]))

(defroutes app_routes
  (GET "/" [] (view/index-page))
  (GET "/api" [] (response {:name "Syed Awase Khirni"}))
  (route/resources "/"))

(def app (wrap-json-response app_routes))

(defn -main [& args] (run-jetty app {:port 9191}))