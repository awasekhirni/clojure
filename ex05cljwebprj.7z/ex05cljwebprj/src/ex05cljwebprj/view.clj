(ns ex05cljwebprj.view
  (:require hiccup.page hiccup.element))

(defn index-page []
  (:html5
    [:html
     [:head]
     [:body "Welcome to Clojure Programming - Syed Awase Khirni!"]]))